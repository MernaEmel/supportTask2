﻿namespace SupportTask2.Models
{
    public class BlogType
    {
        public int Id { get; set; }
        public String Name { get; set; }

    }
}
