﻿using Microsoft.AspNetCore.Mvc;
using SupportTask2.Models;

namespace SupportTask2.Controllers
{
    public class DashBoardController : Controller
    {
        private static List<Blog> blogs = new List<Blog>();

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AddBlog() { 
        return View();
        }
        [HttpPost]
        public IActionResult AddBlog(Blog blog)
        {
            int id;
            if (blogs.Count == 0)
            {
                id = 1;
            }
            else
            {
                id = blogs.Max(x => x.Id) + 1;
            }
            blog.Id = id;
            blogs.Add(blog);


            return RedirectToAction("index");
        }
        #region GetData
        public IActionResult GetAllData()
        {
            return View(blogs);
        }
        #endregion
        #region DeleteBlog
        public IActionResult DeleteBlog(int id)
        {
            Blog blog= blogs.FirstOrDefault(x => x.Id == id);
            blogs.Remove(blog);
            return RedirectToAction("GetAllData");
        }
        #endregion
        #region EditBlog
        public IActionResult EditBlog(int id)
        {
            Blog blog= blogs.FirstOrDefault(y => y.Id == id);

            return View(blog);
        }
        [HttpPost]
        public IActionResult EditBlog(Blog blog)
        {
            Blog b= blogs.FirstOrDefault(z => z.Id == blog.Id);
            b.Id = blog.Id;
            b.Title = blog.Title;
            b.Description = blog.Description;
            b.Type.Id= blog.Type.Id;
            return RedirectToAction("index");
            
        }
        #endregion




    }
}
